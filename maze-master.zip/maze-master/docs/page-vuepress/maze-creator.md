# Maze creator

You can create more mazes for your own testing through [http://127.0.0.1:8000/maze-creator](http://127.0.0.1:8000/maze-creator).