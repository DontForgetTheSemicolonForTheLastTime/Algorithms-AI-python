# Installation

1. Activate the anaconda environment.

2. Install dependencies: `conda install fastapi uvicorn`.

3. Run `uvicorn main:app --reload` in the terminal.

4. Go to `http://127.0.0.1:8000`.
